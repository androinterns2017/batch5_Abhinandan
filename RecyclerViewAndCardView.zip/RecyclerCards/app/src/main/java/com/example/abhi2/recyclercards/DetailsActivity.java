package com.example.abhi2.recyclercards;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class DetailsActivity extends AppCompatActivity {
    private TextView name,description;
    private Bundle extra;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        extra = getIntent().getExtras();
        name = (TextView)findViewById(R.id.dNameId);
        description = (TextView)findViewById(R.id.dDescriptionId);

        if(extra!=null)
        {
            name.setText(extra.getString("name"));
            description.setText(extra.getString("description"));
        }
    }
}

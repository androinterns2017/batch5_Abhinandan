package com.example.abhi2.toastnotify;

import android.app.NotificationManager;
import android.content.Context;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button customToast = (Button) findViewById(R.id.buttonToast);

        customToast.setOnClickListener(new View.OnClickListener() {
                                           @Override
                                           public void onClick(View view) {
                                               LayoutInflater inflator = getLayoutInflater();
                                               View layout = inflator.inflate(R.layout.custom_toast, (ViewGroup) findViewById(R.id.toast_layout_root));
                                               TextView toastText = (TextView) findViewById(R.id.toastText);
//                ImageView toastimage = (ImageView)findViewById(R.id.toastImage);
//                toastText.setText("Custom Toast");
//                toastimage.setImageResource(R.drawable.ic_launcher);
                                               Toast toast = new Toast(getApplicationContext());
                                               toast.setDuration(Toast.LENGTH_LONG); // set the duration for the Toast
                                               toast.setView(layout); // set the inflated layout
                                               toast.show();

                                           }
                                       }
        );

    }

    public void sendNotification(View view) {

        //Get an instance of NotificationManager//

        NotificationCompat.Builder mBuilder =
                new NotificationCompat.Builder(this)
                        .setSmallIcon(R.drawable.ic_launcher_background)
                        .setContentTitle("My notification")
                        .setContentText("Hello World!");




        NotificationManager mNotificationManager =

                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);



//        NotificationManager.notify().

                mNotificationManager.notify(001, mBuilder.build());
    }
}










